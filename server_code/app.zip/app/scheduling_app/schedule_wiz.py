import webapp2
import jinja2
import os
import sys
import pickle

from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.api import mail

from app_scripts.visualize_program import *
from app_scripts.optimalsemester import *
from app_scripts.possible_schedules import *
from app_scripts.visualize_schedule import *
#from app_scripts.vsb_url import *

from app_data.program_titles import *
from app_data.program_graph import *
from app_data.course_database import *
from app_data.teacher_data import *

from utils import *

template_dir = os.path.join( os.path.dirname(__file__), 'templates' ) # makes templates visible:
jinja_env = jinja2.Environment(loader = jinja2.FileSystemLoader(template_dir), autoescape = True)
    

class Users(db.Model):
    password_hash = db.StringProperty(required = True)
    email = db.EmailProperty(required = True)
    
    school = db.StringProperty()
    major = db.StringProperty()
    minor = db.StringProperty()
    minor_second = db.StringProperty()
    
    program_sections = db.TextProperty()
    completed_courses = db.TextProperty()
    filter_preference = db.IntegerProperty()
    
    fall_courses = db.Text()
    winter_courses = db.Text()


class Handler(webapp2.RequestHandler):
    
    def convert_code_to_name(self, sections):
	n_sections = {}
	for s in sections:
	    tmp = []
	    for c in sections[s]:
		try:
		    tmp.append( course_database[c]['name'] )
		except:
		    print "Wasnt able to add " + c
	    n_sections[s] = tmp
	    
	return n_sections
	    
	
    
    def getUsersData(self):
	
	user_id_str = self.request.cookies.get('user_id')
	
	if user_id_str and check_secure_val(user_id_str):
	
	    userdata = memcache.get(user_id_str)
		    
	    if userdata == None:
		user = Users.get_by_id(int(user_id_str.split('|')[0]) )
		memcache.set(user_id_str, user )
    
	    return memcache.get(user_id_str)
	
	else:
	    return None
    '''
    def isloggedIn(self):
        user_id_str = self.request.cookies.get('user_id')
        if user_id_str and check_secure_val(user_id_str):
            if Users.get_by_id(int(user_id_str.split('|')[0]) ).username != None
            return True
        else:
            return False
    '''
    def email_in_db(self, email):
	print "Email: " + email
    	q = db.GqlQuery("Select * FROM Users WHERE email=:e",e=email)
	'''
	users = db.GqlQuery("Select * FROM Users")
	
	
	for u in users:
	    print u.email
	'''
        email_exists = None if q.count() == 0 else q
        return email_exists
    
    def p_logout(self):
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.headers.add_header('Set-Cookie', 'user_id=;Path=/')
        self.response.headers['Content-Type'] = 'text/html'
        time.sleep(1)
        self.redirect('/index')
	
    def p_home(self):
	self.redirect("/index")

    def p_schedule(self):
        self.redirect('/interface')
	
    def p_profile(self):
	self.redirect('/profile')

    def write(self, *a, **kw ):
        self.response.write(*a, **kw)
        
    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params) # this render call is not same as below
    
    def my_render(self, template, **kw):
        self.write(self.render_str(template, **kw))
    

class Index(Handler):
    
    def determine_sections(self, major ,minor1, minor2):
	todo_courses = []
	for p in [major, minor1, minor2]:
    
	    try:
		for c in program_graph[p]:
		    todo_courses.append(c)
	    except:
		pass
	    
	return set(todo_courses)
            
    def render_front(self, ud, pe='',ve='',ee='',iu=''):
        loggedout = True if ud == None else False
        self.my_render('front.html', loggedout=loggedout,
                       major=program_titles, minor=program_titles, 
                       ee=ee, pe=pe, ve=ve,
                       iu=iu)
    
        
    def p_signup(self):
        d_email = self.request.get('d_email')
        d_password = self.request.get('d_password')
        verify = self.request.get('verify')
        
        major = self.request.get('major')
        minor = self.request.get('minor')
        minor2 = self.request.get('sec_minor')
        
        email_exists = self.email_in_db(d_email)
	
	#print d_email, d_password, verify, major, minor, minor2
	
	#print email_exists, v_em(d_email), v_pw(d_password), v_vpw(verify, d_password)
        
        if  email_exists == None and v_em(d_email) and v_pw(d_password) and v_vpw(verify,d_password):
	    
	    program_sections = program_graph[major]
	    #print "program sections"
	    #print program_sections
	    
            new_user = Users( email=d_email, password_hash = make_pw_hash(d_email, d_password),
			     major=major, minor=minor2, program_sections=pickle.dumps(program_sections),
			     completed_courses='gfdgdfgdfgdf', filter_preference=1, fall_courses='', winter_courses='')
            key = new_user.put()
	    
	    print pickle.dumps(program_sections)
    
            self.response.headers['Content-Type'] = 'text/plain'
            self.response.headers.add_header('Set-Cookie', 'user_id=%s;Path=/' % make_secure_val(str(int(key.id()) ) ) )
            self.response.headers['Content-Type'] = 'text/html'
            time.sleep(1)
            self.redirect('/interface')
            
        else:
	    
	    #print "Signup Failed"
            ee,pe,ve = "Sorry, that that email is taken." if email_exists else "Invalid Email" ,"Invalid Password","Passwords Don't Match"
     	    invalid_email = v_em(d_email)
            invalid_password = v_pw(d_password)
            invalid_verification = v_vpw(verify,d_password)
            self.render_front(  None, ee = ee if (invalid_email or email_exists) else "",
                                pe = pe if invalid_password else "",
                                ve = ve if invalid_verification else ""
                                )

        
    def p_login(self):
        email = self.request.get('login_email')
        password = self.request.get('login_password')
	#print email,password
	
        email_exists = self.email_in_db(email)
        
        if email_exists:
            u = email_exists.fetch(1)[0]
            pw_hash = u.password_hash
            if valid_pw(email, password, pw_hash):
                self.response.headers['Content-Type'] = 'text/plain'
                self.response.headers.add_header('Set-Cookie', 'user_id=%s;Path=/' % make_secure_val(str(int(u.key().id() ) ) ) )
                self.response.headers['Content-Type'] = 'text/html'
                time.sleep(1)
                self.redirect("/profile")
            
            else:
                self.render_front(None, iu="Invalid Password")
                
        else:
            self.render_front(None, iu="Invalid Email")
        
    def p_forgot_password(self):
        mail.send_mail("Example.com Support <lucaslangermont9@gmail.com>",
              "Lucas Langer <lucaslangermont9@gmail.com>",
              "Your account has been approved",
              """
                Dear Albert:
                
                Your example.com account has been approved.  You can now visit
                http://www.example.com/ and sign in using your Google Account to
                access new features.
                
                Please let us know if you have any questions.
                
                The example.com Team
                """)
        self.redirect('/index')

#dev_appserver.py --smtp_host=smtp.gmail.com --smtp_port=465 --smtp_user=lucaslangermont9@gmail.com --smtp_password=elgoog09 app
    
        
    def get(self):
	ud = self.getUsersData()
        self.render_front( ud )

    def post(self):
        is_get_schedule = self.request.get('get_schedule')
	is_profile = self.request.get('profile')
        is_login = self.request.get('login')
        is_signup = self.request.get('signup')
        is_logout = self.request.get('logout')
        is_forgot_password = self.request.get('forgot_password')
	
	#print is_get_schedule, is_profile, is_login, is_signup, is_logout, is_forgot_password
        
        if is_get_schedule:
            self.p_schedule()
            
        elif is_login:
            self.p_login()
            
        elif is_signup:
            self.p_signup()
            
        elif is_logout:
            self.p_logout()
        
        elif is_forgot_password:
            self.p_forgot_password()
        
class Interface(Handler):
    
    def render_interface(self, optimalfall, optimalwinter , vs ):
        self.my_render('results.html', optimalfall=optimalfall, optimalwinter=optimalwinter, vis_sched=vs)

    def get(self):
	ud = self.getUsersData()
	if ud != None:
	    major = ud.major
	    
	    possibilites = gen_possible_schedules(course_database, program_graph[major] )
	    osched = optimal(course_database, possibilites, teacher_data)
	    if osched:
		vis_sched = visualize_schedule(osched)
	    else:
		osched = []
		vis_sched = []
		#url = get_vsb_url(course_database, osched)
	    
	    self.render_interface(osched, osched, vis_sched)
	    
	else:
	    self.redirect("/index")
        
    def post(self):
        is_logout = self.request.get('logout')
	is_profile = self.request.get('profile')
	is_home = self.request.get('home')
        is_update_filter = self.request.get('update_filter')
        
        if is_logout:
            self.p_logout()
	
	elif is_profile:
	    self.p_profile()
	    
	elif is_home:
	    self.p_home()

class Profile(Handler):
    def render_profile(self , ud, nodes=[], edges=[]):
	nodes, edges = visualize(ud.major, program_graph, course_database)
	program_sections = pickle.loads(ud.program_sections)
	program_names = self.convert_code_to_name(program_sections)
    	self.my_render('profile.html', user = ud, program_sections=program_sections, n_sections = program_names,
		       nodes=nodes, edges=edges, course_database=course_database)

    def get(self):
	ud = self.getUsersData()
	if ud != None:
	    self.render_profile(ud)
	else:
	    self.redirect('/index')
    
    def post(self):
        is_logout = self.request.get('logout')
	is_schedule = self.request.get('get_schedule')
	is_home = self.request.get('home')
	
        if is_logout:
            self.p_logout()
	    
	elif is_schedule:
	    self.p_schedule()
        
	elif is_home:
	    self.p_home()

app = webapp2.WSGIApplication(  [('/index', Index),  
                                 ('/interface', Interface),
                                 ('/profile', Profile)]
                                ,debug=True)    