def visualize_old(program_title, program_graph):
        
    with open("visual_test.dot", "w") as f3:
        sections = program_graph[program_title]
        f3.write("digraph G {\n")

    
        
        for v in courses:
            prereq = course_graph[v]['prereq']
            
            for p in prereq:
                if p.replace("_","-") in graph: # the replacement is a temporary bugfix that occured because of previous improper formatting in build_course_graph (prereq section)
                    f3.write("\t" + p.replace("-","_") + " -> " + v.replace("-","_") + ";\n")
                    print p
                else:
                    print "Excluded " + p
            
        f3.write('}')


def visualize(program_title, program_graph, course_database):
    edges = []
    nodes = []
    ids = {}

    print program_graph, program_title
    sections = program_graph[program_title]
    counter = 1

    print sections

    courses = {}
    for s in sections:
        for c in sections[s]:
            courses[c] = True

    course_set = set(courses.keys() )

    DIR = '/static/images/graph-icons/'

    for v in course_set:
        print v
        if v in course_database:
            
            ids[v] = counter
            nodes.append({'id':counter, 'mass':100, 'label':v, 'image': DIR + 'engr.png', 'level':1, 'shape':'image', 'value': 1500, 'fontFace': 'Helvetica'})
            counter += 1
       
    for v in courses:
        if v in course_database:
            for pre in course_database[v]['prereq']:
                if pre in courses and pre in course_database:
                    edges.append( {'from': ids[pre], 'to': ids[v], 'style': 'arrow', 'width':'0.25' })

    return nodes,edges
#visualize("Honours_Applied_Mathematics_(60_credits)")
