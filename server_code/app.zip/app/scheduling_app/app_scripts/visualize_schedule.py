from test_schedule import *
import math

def visualize_schedule( optimal): #already been validated

	skipcounters = {'M':0, 'T':0, 'W':0, 'R':0, 'F':0} #intuitive format, to be converted later in convert_sched_Format
	weekarray =[ {'M':0, 'T':0, 'W':0, 'R':0, 'F':0} for i in range(20)] #chars: streak, empty
	for i in range(20):
		for d in "MTWRF":
			if skipcounters[d] != 0:
				weekarray[i][d] = -1
				skipcounters[d] += -1
			else:
				for c in range(len(optimal)):
					o = optimal[c]
					a = is_active_course(i,d,o)
					
					if a:
						time = convert_time(o[1])
						length = math.ceil( ((time[1] - time[0])*1.0)/30.0)

						weekarray[i][d] = [o[0], length ,c]
						skipcounters[d] = length - 1
						break

	return convert_sched_format(weekarray)

def convert_sched_format(weekarray):
	minuterow = 0
	sched = []
	for r in weekarray:
		mrmod2 = minuterow % 2
		if mrmod2 == 0:
			h = (8 + (minuterow-mrmod2)/2)
			if h > 12:
				h = h - 12
			na = [h, []]
		else:
			na = ['', []]
		for d in 'MTWRF':
			if r[d] == 0:
				na[1].append(0)
			elif r[d] != -1:
				na[1].append(r[d])

		sched.append(na)
		minuterow += 1

	return sched




def is_active_course(i,d,o):
	days = o[2]
	time = convert_time(o[1])
	if d in days:
		c = collision( [480+i*30,480+(i+1)*30], time ) 
		#if c:
		#	print time, str(540+i*15) + str(540+(i+1)*15)
		return c
	else:
		return False