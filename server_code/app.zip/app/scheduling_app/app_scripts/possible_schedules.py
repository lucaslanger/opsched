import itertools
import re

from test_schedule import *

valid, invalid = 0,0

def gen_possible_schedules(course_database, program, completed={}, semester='fall', load = 5): # should also take, semester that one starts from and completed courses
    
        schedules = []
        
        candidates = determine_candidates(course_database, program, semester, completed)
        print candidates
	
	combs = list(itertools.combinations(candidates, min(load,len(candidates) ) ) )

	for c in combs:
	    schedules.extend( find_valid_combs(course_database, c, semester) )
	    
	print valid, invalid
    
	return schedules

def gen_program_keys(program):
	keys = {}
	for s in program:
		for p in s:
			keys[p] = True
	return keys
	
    
def determine_candidates(course_database, program ,semester ,completed):
	cands = []
	mc = max_completed(completed)
	p_keys = gen_program_keys(program)
	
	
	keys = []
	for s in program:
		keys.extend(program[s])
		
	keys = set(keys)
	
	for key in keys:
	    try:
		active = course_database[key].has_key(semester)
	    except:
		print key + " not in course_database"
		active = False
	
	    try:
		year1course = re.findall('-[0-9]+',key)[0][1] == '1'
	    except:
		year1course = False
		print key
	    
	    
	    if key not in completed and active and year1course==False:
		
		candidate_level = int(re.findall("-[0-9]{3,6}", key)[0][1])
		
		if candidate_level > (mc + 1):
		    print key, "Level too high" , candidate_level, mc+1
		    possible = False
		else:
		    possible = True
		
		    for p in course_database[key]['prereq']:
			try:
				pl = int( re.findall(r'-[0-9]{3,6}', p)[0][1] ) #prerequisite level
			except:
				print "Weird Prerequisite Level", p
				pl = 1
				
			if pl > 1 and pl not in completed and p_keys.has_key(p): #ignores prereqs below 100 level
				print key, "prereq not completed", p
				possible = False
				break
		
		if possible:    
		    cands.append(key)			

	return cands

def max_completed(completed):
    m = 1
    for c in completed.keys():
	l = int(re.findall(r'-[0-9]{3,6}', c)[0][1])
	if l > m:
	    m = l
	    
    return m
    
def find_valid_combs(course_database, courses, semester): #possible optimization by looking at n choose 2 first, and eliminating collisions.. would only reduce constant by about 2 according to tests   
    global valid, invalid
    semester_components = []
    for co in courses:
	cd = course_database[co][semester]
	lectures = []
	tutorials = [] # do we want this?
	labs = []
	for p in cd:
	    t = p['Type']
	    if t == 'Lecture':
		p['Course'] = co 
		lectures.append(p)
		
	    elif t == 'Laboratory':
		p['Course'] = co
		labs.append(p)
		
	    elif t == 'Tutorial':
		p['Course'] = co
		tutorials.append(p)
		
	if len(lectures) > 0:
	    semester_components.append(lectures)
	if len(labs) > 0:
	    semester_components.append(labs)
	if len(tutorials) > 0:
	    semester_components.append(tutorials)
	
    combs = []
    gen_combs( semester_components ,combs)
    valid_pairs = {}
    valid_combs = []
    possible = True
    
    for c in combs:
	##hashtable reduces time by a factor of 2
	pairs = list(itertools.combinations(c,2))
	for p in pairs:
		tuple_rep = frozenset( [p[0]['Crn'], p[1]['Crn']] )
		if valid_pairs.has_key(tuple_rep):
			
			if valid_pairs[tuple_rep] == False:
				possible = False
				break
		else:
			
			if test_schedule(p):
				valid_pairs[tuple_rep] = True
			else:
				valid_pairs[tuple_rep] = False
				possible = False
				break
	if possible:
		valid_combs.append(c)
	
	'''
	v = test_schedule(c)
	if v:
	    valid_combs.append(c)
	    valid += 1
	else:
	    invalid += 1
	'''
    return valid_combs
    
    #combo doenst neccesarily have to be 5 courses cuz of labs, etc
    
def gen_combs(components, combs ,prefix = []):
    if len(components) == 0:
	combs.append(prefix[::])
    else:	
	for p in components[0]:
	    prefix.append(p)
	    gen_combs(components[1:], combs, prefix)
	    prefix.pop()
	    
def test():
	
	courses = ['COMP-202', 'EDEC-201', 'EDEC-215', 'EDEC-247', 'EDEC-262', 'EDFE-200', 'EDPE-300', 'EDPE-304', 'EDEC-248', 'EDEC-249', 'EDEC-260', 'EDEC-261', 'BIOL-200', 'BIOL-215', 'BIOL-373', 'CHEM-203', 'CHEM-212', 'CHEM-253', 'CHEM-287', 'CHEM-297', 'BIOL-210', 'MATH-203', 'MATH-222']
	